# -*- coding: utf-8 -*-
import os, re, math, json, sqlite3
from datetime import datetime
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.widget import Widget
from kivy.uix.popup import Popup
from kivy.core.window import Window
from kivy.clock import Clock as KvClock
from kivy.graphics import Color, Line, Ellipse

Window.clearcolor = (0.045, 0.055, 0.07, 1)

def asset_path(name):
    return os.path.join(os.path.dirname(__file__), "assets", name)

def load_tasks():
    with open(asset_path("tasks.json"), "r", encoding="utf-8") as f:
        return json.load(f)

GROUPS = load_tasks()
ALL_TASKS = []
for group in GROUPS:
    for item in group.get("items", []):
        x = dict(item)
        x["group"] = group.get("g", "Раздел")
        ALL_TASKS.append(x)

# ---------- база ----------
DB_CON = None
def db_path():
    d = App.get_running_app().user_data_dir
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "clock_assistant.db")

def db_init():
    global DB_CON
    DB_CON = sqlite3.connect(db_path())
    DB_CON.execute("""CREATE TABLE IF NOT EXISTS history(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        time TEXT, question TEXT, answer TEXT)""")
    DB_CON.commit()

def db_save(q, a):
    if DB_CON:
        DB_CON.execute("INSERT INTO history(time,question,answer) VALUES(?,?,?)",
                       (datetime.now().strftime("%d.%m %H:%M"), q, a))
        DB_CON.commit()

# ---------- старый решатель ----------
def nums_of(s):
    return [float(x) for x in re.findall(r'-?\d+\.?\d*', s)]

def solve_simple(raw):
    q = raw.strip()
    cleaned = re.sub(r'[^0-9+\-*/(). ]', '', q).strip()
    if cleaned and re.search(r'\d', cleaned) and re.search(r'[+\-*/]', cleaned):
        try:
            val = eval(cleaned, {"__builtins__": {}})
            return "Результат: %s = %s\n\nPython использует приоритет операций: скобки → степень → умножение/деление → сложение/вычитание." % (cleaned, val)
        except Exception:
            pass
    n = nums_of(q.lower())
    low = q.lower()
    if 'факториал' in low:
        k = int(n[0]) if n else 5
        return "%d! = %d" % (k, math.factorial(k))
    if 'прост' in low:
        k = int(n[0]) if n else 97
        ok = k > 1 and all(k % i for i in range(2, int(k**0.5)+1))
        return "%d — %s" % (k, "простое число" if ok else "не простое")
    if 'корен' in low:
        v = n[0] if n else 144
        return "√%s = %s" % (v, math.sqrt(v))
    return "Не распознано. Попробуй: 25 * 4 + 10, факториал 5, простое число 97 или корень 144."

# ---------- моя версия объяснения ----------
def explain_task(item):
    d = item.get("d", "")
    c = item.get("c", "")
    low = d.lower()
    topic = item.get("group", "")

    tips = []
    if any(x in low for x in ["print", "вывести"]): tips.append("print() выводит значение на экран.")
    if "input" in low or "ввод" in low: tips.append("input() получает текст от пользователя; для числа обычно используют int() или float().")
    if "арифмет" in low or any(x in low for x in ["сумм", "площад", "степен", "цифр"]): tips.append("Сначала определи, какие данные нужны, затем запиши формулу и только после этого код.")
    if "услов" in low or "логик" in low or item.get("group") in ["Boolean", "If", "Case"]: tips.append("Условие проверяется через if. Операторы сравнения: ==, !=, <, >, <=, >=.")
    if item.get("group") in ["For", "While", "Series"]: tips.append("В цикле важно определить начальное значение, условие продолжения и изменение счётчика.")
    if item.get("group") in ["Array", "Matrix"]: tips.append("Для списка индекс начинается с 0. Для матрицы обычно используются два индекса: строка и столбец.")
    if item.get("group") == "String": tips.append("Строка — последовательность символов. Полезны len(), split(), join(), find(), replace(), upper() и lower().")
    if item.get("group") == "File": tips.append("Для файлов удобно использовать with open(...): — файл автоматически закроется после блока.")
    if item.get("group") == "Proc": tips.append("Функция создаётся через def и может возвращать результат через return.")
    if item.get("group") == "Minmax": tips.append("Минимум и максимум можно искать встроенными min()/max() или вручную циклом.")
    if not tips: tips.append("Посмотри на входные данные, затем разбей решение на маленькие шаги и проверь результат на простом примере.")

    return "Моя версия объяснения\n\nРаздел: %s\nЗадача №%s: %s\n\n%s\n\nЧто делать:\n1. Понять условие.\n2. Определить входные данные.\n3. Выполнить основную операцию.\n4. Вывести результат.\n\nГотовый ответ ниже можно использовать как образец, но полезнее сначала попробовать решить самому." % (
        topic, item.get("n", "?"), d, "\n".join("• " + x for x in tips)
    )

# ---------- часы ----------
class Dial(BoxLayout):
    def __init__(self, **kw):
        super().__init__(orientation='vertical', **kw)
        self.lab = Label(font_size='42sp', color=(0.85,0.92,1,1))
        self.date = Label(font_size='13sp', color=(0.55,0.65,0.75,1))
        self.add_widget(Widget())
        self.add_widget(self.lab)
        self.add_widget(self.date)
        self.add_widget(Widget())
        KvClock.schedule_interval(self.tick, 1)
        self.tick(0)
    def tick(self, dt):
        now = datetime.now()
        self.lab.text = now.strftime("%H:%M:%S")
        self.date.text = now.strftime("%d.%m.%Y")

class TaskDetail(BoxLayout):
    def __init__(self, item, **kw):
        super().__init__(orientation='vertical', padding=10, spacing=7, **kw)
        title = Label(text="[%s]  №%s\n%s" % (item.get("group"), item.get("n"), item.get("d")),
                      font_size='16sp', bold=True, color=(0.9,0.95,1,1),
                      size_hint_y=None, halign='left', valign='middle')
        title.bind(texture_size=title.setter('size'))
        self.add_widget(title)

        tabs = BoxLayout(size_hint_y=None, height=44, spacing=5)
        b1 = Button(text="Ответ")
        b2 = Button(text="Моя версия")
        tabs.add_widget(b1); tabs.add_widget(b2)
        self.add_widget(tabs)

        sv = ScrollView()
        self.text = Label(text="", font_size='13sp', color=(0.82,0.88,0.95,1),
                          halign='left', valign='top', size_hint_y=None)
        self.text.bind(texture_size=self.text.setter('size'))
        sv.add_widget(self.text)
        self.add_widget(sv)

        def show_answer(*_):
            self.text.text = "ГОТОВЫЙ ОТВЕТ\n\n" + item.get("c","")
        def show_explain(*_):
            self.text.text = explain_task(item)
        b1.bind(on_press=show_answer)
        b2.bind(on_press=show_explain)
        show_answer()

class TaskBrowser(BoxLayout):
    def __init__(self, go_home, **kw):
        super().__init__(orientation='vertical', padding=8, spacing=6, **kw)
        self.go_home = go_home
        top = BoxLayout(size_hint_y=None, height=44, spacing=5)
        back = Button(text="← Назад", size_hint_x=.22)
        self.search = TextInput(hint_text="Поиск по 807 задачам...", multiline=False)
        top.add_widget(back); top.add_widget(self.search)
        self.add_widget(top)
        back.bind(on_press=lambda *_: self.go_home())

        self.list_box = GridLayout(cols=1, spacing=5, size_hint_y=None)
        self.list_box.bind(minimum_height=self.list_box.setter('height'))
        sv = ScrollView()
        sv.add_widget(self.list_box)
        self.add_widget(sv)

        self.search.bind(text=lambda *_: self.refresh())
        self.refresh()

    def refresh(self):
        self.list_box.clear_widgets()
        q = self.search.text.lower().strip()
        shown = 0
        for item in ALL_TASKS:
            hay = ("%s %s %s" % (item.get("group",""), item.get("n",""), item.get("d",""))).lower()
            if q and q not in hay:
                continue
            btn = Button(text="%s  •  №%s  •  %s" % (item.get("group"), item.get("n"), item.get("d")),
                         size_hint_y=None, height=52, halign='left')
            btn.bind(on_press=lambda _, it=item: self.open_task(it))
            self.list_box.add_widget(btn)
            shown += 1
            if shown >= 150 and not q:
                break

    def open_task(self, item):
        Popup(title="Задача Абрамяна",
              content=TaskDetail(item),
              size_hint=(0.96,0.9)).open()

class Root(BoxLayout):
    def __init__(self, **kw):
        super().__init__(orientation='vertical', padding=8, spacing=7, **kw)
        self.content = BoxLayout(orientation='vertical')
        self.add_widget(self.content)
        self.show_home()

    def clear(self):
        self.content.clear_widgets()

    def show_home(self):
        self.clear()
        self.content.add_widget(Dial())

        info = Label(text="Clock Assistant\n\n807 задач по Python\n15 разделов\nОтветы + моя версия объяснения\nПоиск по задачам работает офлайн.",
                     font_size='15sp', color=(0.82,0.9,1,1), halign='center', valign='middle')
        self.content.add_widget(info)

        row = BoxLayout(size_hint_y=None, height=55, spacing=6)
        tasks = Button(text="📚 Задачи Абрамяна")
        solve = Button(text="🧮 Решатель")
        row.add_widget(tasks); row.add_widget(solve)
        self.content.add_widget(row)
        tasks.bind(on_press=lambda *_: self.show_tasks())
        solve.bind(on_press=lambda *_: self.show_solver())

    def show_tasks(self):
        self.clear()
        self.content.add_widget(TaskBrowser(self.show_home))

    def show_solver(self):
        self.clear()
        back = Button(text="← Назад", size_hint_y=None, height=45)
        self.content.add_widget(back)
        box = BoxLayout(orientation='vertical', spacing=6)
        out = Label(text="Напиши пример, например: 25 * 4 + 10", halign='left', valign='top',
                    color=(0.82,0.9,1,1), size_hint_y=None)
        out.bind(texture_size=out.setter('size'))
        sv = ScrollView(); sv.add_widget(out)
        box.add_widget(sv)
        row = BoxLayout(size_hint_y=None, height=52, spacing=5)
        inp = TextInput(hint_text="Задача...", multiline=False)
        btn = Button(text="Решить", size_hint_x=.3)
        row.add_widget(inp); row.add_widget(btn)
        box.add_widget(row)
        self.content.add_widget(box)
        back.bind(on_press=lambda *_: self.show_home())
        def ask(*_):
            q=inp.text.strip()
            if q:
                a=solve_simple(q)
                out.text += "\n\n" + a
                db_save(q,a)
                inp.text=""
        btn.bind(on_press=ask)
        inp.bind(on_text_validate=ask)

class ClockApp(App):
    def build(self):
        db_init()
        self.title = "Clock Assistant + Abramyan"
        return Root()

if __name__ == "__main__":
    ClockApp().run()
