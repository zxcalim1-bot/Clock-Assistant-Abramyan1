[app]
title = Clock Assistant + Abramyan
package.name = clockassistantabramyan
package.domain = org.alim
source.dir = .
source.include_exts = py,json,txt
version = 2.0
requirements = python3,kivy
orientation = portrait
fullscreen = 0

[buildozer]
log_level = 2
warn_on_root = 1

[app:android]
android.api = 35
android.minapi = 23
android.archs = arm64-v8a
